/*    */ package com.structure;
/*    */ 
/*    */ import com.resource.Resource;
/*    */ import java.awt.Color;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ public static enum Structure
/*    */ {
/* 13 */   SETTLEMENT("settlement"), CITY("city");
/*    */   
/*    */   protected HashMap<Color, BufferedImage> outlines;
/*    */   
/*    */   protected BufferedImage sprite;
/*    */   
/*    */   protected Map<Resource, Integer> required;
/*    */   protected String name;
/*    */   
/* 22 */   Structure(String name) { this.name = name; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void init() {
/* 28 */     this.outlines = new HashMap();
/*    */     
/*    */     try {
/* 31 */       this.sprite = ImageIO.read(getClass().getResource("/com/structure/" + this.name + ".png"));
/* 32 */     } catch (IOException iOException) {}
/*    */ 
/*    */ 
/*    */     
/* 36 */     this.outlines.put(Color.RED, chooseColor(Color.RED));
/* 37 */     this.outlines.put(Color.BLUE, chooseColor(Color.BLUE));
/* 38 */     this.outlines.put(Color.YELLOW, chooseColor(Color.YELLOW));
/* 39 */     this.outlines.put(Color.GREEN, chooseColor(Color.GREEN));
/*    */     
/* 41 */     this.required = new HashMap();
/* 42 */     if (this.name.equals("settlement")) {
/* 43 */       this.required.put(Resource.GRAIN, new Integer(true));
/* 44 */       this.required.put(Resource.LUMBER, new Integer(true));
/* 45 */       this.required.put(Resource.STONE, new Integer(true));
/* 46 */       this.required.put(Resource.WOOL, new Integer(true));
/* 47 */     } else if (this.name.equals("city")) {
/* 48 */       this.required.put(Resource.GRAIN, new Integer(2));
/* 49 */       this.required.put(Resource.ORE, new Integer(3));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/* 54 */   public Map<Resource, Integer> req() { return this.required; }
/*    */ 
/*    */ 
/*    */   
/* 58 */   public BufferedImage getSprite() { return this.sprite; }
/*    */ 
/*    */ 
/*    */   
/* 62 */   public BufferedImage getOutline(Color c) { return (BufferedImage)this.outlines.get(c); }
/*    */ 
/*    */ 
/*    */   
/* 66 */   public String getName() { return this.name; }
/*    */ 
/*    */   
/*    */   public BufferedImage chooseColor(Color c) {
/*    */     try {
/* 71 */       System.out.println(c.getRGB());
/* 72 */       return ImageIO.read(getClass().getResource("/com/structure/" + this.name + "_outline" + c.getRGB() + ".png"));
/* 73 */     } catch (IOException e) {
/*    */       
/* 75 */       e.printStackTrace();
/*    */       
/* 77 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\structure\Structure.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */