/*     */ package com.units;
/*     */ 
/*     */ import com.assets.Player;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import javax.imageio.ImageIO;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Unit
/*     */ {
/*     */   private int amount;
/*     */   private static ArrayList<BufferedImage> sprites;
/*     */   private Player p;
/*     */   private int newU;
/*     */   
/*  20 */   public Unit() { this.amount = 0; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Unit(int amount, Player p) {
/*  25 */     this.amount = amount;
/*  26 */     this.p = p;
/*  27 */     this.newU = amount;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  33 */   public int getAmount() { return this.amount; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add() {
/*  39 */     this.amount++;
/*  40 */     this.newU++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  46 */   public boolean check(int i) { return (this.amount - this.newU >= -1 * i); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  52 */   public int getAvailable() { return this.amount - this.newU; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void add(int i) throws Exception {
/*  58 */     if (check(i)) {
/*  59 */       this.amount += i;
/*  60 */       this.newU += i;
/*     */     } else {
/*  62 */       throw new Exception();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  69 */   public void reset() { this.newU = 0; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public Player getPlayer() { return this.p; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void loadGraphics() {
/*  81 */     sprites = new ArrayList();
/*     */     try {
/*  83 */       sprites.add(ImageIO.read(getClass().getResource(
/*  84 */               "/com/units/Unit-1.png")));
/*  85 */     } catch (IOException e) {
/*  86 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/*  90 */       sprites.add(ImageIO.read(getClass().getResource(
/*  91 */               "/com/units/Unit-2.png")));
/*  92 */     } catch (IOException e) {
/*  93 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/*  97 */       sprites.add(ImageIO.read(getClass().getResource(
/*  98 */               "/com/units/Unit-3.png")));
/*  99 */     } catch (IOException e) {
/* 100 */       e.printStackTrace();
/*     */     } 
/*     */     
/*     */     try {
/* 104 */       sprites.add(ImageIO.read(getClass().getResource(
/* 105 */               "/com/units/Unit-Many.png")));
/* 106 */     } catch (IOException e) {
/* 107 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public BufferedImage getSprite() {
/* 114 */     if (this.amount == 1)
/* 115 */       return (BufferedImage)sprites.get(0); 
/* 116 */     if (this.amount == 2)
/* 117 */       return (BufferedImage)sprites.get(1); 
/* 118 */     if (this.amount == 3) {
/* 119 */       return (BufferedImage)sprites.get(2);
/*     */     }
/* 121 */     return (BufferedImage)sprites.get(3);
/*     */   }
/*     */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\co\\units\Unit.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */