/*     */ package com.main;
/*     */ 
/*     */ import com.assets.Menu;
/*     */ import com.assets.World;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.image.BufferStrategy;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Main
/*     */   extends Canvas
/*     */   implements Runnable
/*     */ {
/*     */   private static final long serialVersionUID = -4503123443658426182L;
/*     */   private JFrame window;
/*     */   private Thread thread;
/*     */   private World world;
/*     */   private Menu menu;
/*     */   private boolean running;
/*     */   private boolean gameRunning;
/*     */   
/*     */   public Main() {
/*  27 */     this.running = false;
/*  28 */     this.gameRunning = false;
/*  29 */     this.menu = new Menu();
/*  30 */     this.window = new JFrame("Settling Risks");
/*  31 */     this.window.setSize(new Dimension('Ұ', '΄'));
/*  32 */     this.window.setDefaultCloseOperation(3);
/*  33 */     this.window.setResizable(false);
/*  34 */     this.window.setLocationRelativeTo(null);
/*  35 */     this.window.add(this);
/*  36 */     this.window.setVisible(true);
/*  37 */     this.window.createBufferStrategy(2);
/*  38 */     addMouseListener(this.menu);
/*  39 */     addMouseMotionListener(this.menu);
/*  40 */     start();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void startGame() {
/*  46 */     this.world = new World(16, 16, 'Ұ', 'ʣ', false, false, this.menu.getPlayers());
/*  47 */     addKeyListener(this.world);
/*  48 */     addMouseListener(this.world);
/*  49 */     addMouseMotionListener(this.world);
/*  50 */     removeMouseListener(this.menu);
/*  51 */     removeMouseMotionListener(this.menu);
/*  52 */     this.gameRunning = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  58 */     requestFocus();
/*  59 */     long lastTime = System.nanoTime();
/*  60 */     double amountOfTicks = 20.0D;
/*  61 */     double ns = 1.0E9D / amountOfTicks;
/*  62 */     double delta = 0.0D;
/*  63 */     long timer = System.currentTimeMillis();
/*  64 */     int frames = 0;
/*  65 */     while (this.running) {
/*  66 */       long now = System.nanoTime();
/*  67 */       delta += (now - lastTime) / ns;
/*  68 */       lastTime = now;
/*  69 */       while (delta >= 1.0D) {
/*  70 */         tick();
/*  71 */         delta--;
/*     */       } 
/*  73 */       if (this.running)
/*  74 */         render(); 
/*  75 */       frames++;
/*  76 */       if (System.currentTimeMillis() - timer > 1000L) {
/*  77 */         System.out.println("FPS: " + frames);
/*  78 */         timer += 1000L;
/*  79 */         frames = 0;
/*     */       } 
/*     */     } 
/*  82 */     stop();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void tick() {
/*  88 */     if (this.gameRunning) {
/*  89 */       this.world.tick();
/*     */     }
/*  91 */     else if (this.menu.checkFinished()) {
/*  92 */       startGame();
/*     */     } 
/*     */     
/*  95 */     if (this.menu.quitGame()) {
/*  96 */       this.window.dispose();
/*  97 */       stop();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/* 104 */     BufferStrategy bs = getBufferStrategy();
/* 105 */     if (bs == null) {
/* 106 */       createBufferStrategy(2);
/*     */       return;
/*     */     } 
/* 109 */     Graphics g = bs.getDrawGraphics();
/*     */     
/*     */     try {
/* 112 */       this.world.render(g);
/* 113 */       g.dispose();
/* 114 */       bs.show();
/* 115 */     } catch (NullPointerException e) {
/* 116 */       this.menu.render(g);
/* 117 */       g.dispose();
/* 118 */       bs.show();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void start() {
/* 125 */     this.thread = new Thread(this);
/* 126 */     this.thread.start();
/* 127 */     this.running = true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/*     */     try {
/* 134 */       this.thread.join();
/* 135 */       this.running = false;
/* 136 */     } catch (Exception e) {
/* 137 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {}
/*     */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\main\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */