/*    */ package com.resource;
/*    */ 
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ public static enum Resource
/*    */ {
/*  9 */   GRAIN("grain"), LUMBER("lumber"), WOOL("wool"), ORE("ore"), STONE("stone");
/*    */   
/*    */   protected String name;
/*    */   protected BufferedImage icon;
/*    */   
/*    */   Resource(String icon) {
/* 15 */     this.name = icon;
/* 16 */     if (this.icon == null) {
/*    */       try {
/* 18 */         this.icon = ImageIO.read(getClass().getResource(
/* 19 */               "/com/resource/" + icon + "Icon.png"));
/* 20 */       } catch (IOException e) {
/* 21 */         System.out.println("failed");
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 29 */   public BufferedImage getIcon() { return this.icon; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 34 */   public String toString() { return this.name; }
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\resource\Resource.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */