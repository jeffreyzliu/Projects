/*    */ package com.terrain;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Location
/*    */ {
/*    */   public static final int NORTH = 0;
/*    */   public static final int EAST = 90;
/*    */   public static final int SOUTH = 180;
/*    */   public static final int WEST = 270;
/*    */   private int x;
/*    */   private int y;
/*    */   
/*    */   public Location() {}
/*    */   
/*    */   public Location(int x, int y) {
/* 19 */     this.x = x;
/* 20 */     this.y = y;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 26 */   public int getX() { return this.x; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 32 */   public int getY() { return this.y; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 37 */   public int hashCode() { return 1000 * this.x + this.y; }
/*    */ 
/*    */ 
/*    */   
/* 41 */   public boolean equals(Object obj) { return (this.x == ((Location)obj).getX() && 
/* 42 */       this.y == ((Location)obj).getY()); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getDirection(Location loc) {
/* 48 */     int absX = loc.getX() - this.x;
/* 49 */     int absY = loc.getY() - this.y;
/* 50 */     if (absX == 0) {
/* 51 */       if (absY < 0)
/*    */       {
/* 53 */         return 180;
/*    */       }
/*    */       
/* 56 */       return 0;
/*    */     } 
/*    */     
/* 59 */     if (absX < 0)
/*    */     {
/* 61 */       return 270;
/*    */     }
/*    */     
/* 64 */     return 90;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 71 */   public String toString() { return "x: " + this.x + ", y: " + this.y; }
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\terrain\Location.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */