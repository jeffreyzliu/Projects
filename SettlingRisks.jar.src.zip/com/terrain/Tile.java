/*    */ package com.terrain;
/*    */ 
/*    */ import com.assets.Player;
/*    */ import com.resource.Resource;
/*    */ import com.units.Unit;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Tile
/*    */ {
/*    */   private Terrain terrain;
/*    */   private Unit u;
/*    */   private int harvestProb;
/*    */   private Location loc;
/*    */   
/*    */   public Tile(Location loc) {
/* 18 */     this.terrain = Terrain.getRandomTerrain();
/* 19 */     this.u = new Unit(false, null);
/* 20 */     this.harvestProb = (int)(Math.random() * 11.0D) + 2;
/* 21 */     this.loc = loc;
/*    */   }
/*    */ 
/*    */   
/*    */   public Tile(Terrain t, Location loc) {
/* 26 */     this.terrain = t;
/* 27 */     this.harvestProb = (int)(Math.random() * 11.0D) + 2;
/* 28 */     this.u = new Unit(false, null);
/* 29 */     this.loc = loc;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 35 */   public BufferedImage getSprite() { return this.terrain.getSprite(); }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 40 */   public Terrain getTerrain() { return this.terrain; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   public void addUnit(Unit u) { this.u = u; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 50 */   public Unit getUnit() { return this.u; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public Location getLoc() { return this.loc; }
/*    */ 
/*    */   
/*    */   public Player getOwner() {
/* 59 */     if (this.u.getAmount() > 0) {
/* 60 */       return this.u.getPlayer();
/*    */     }
/* 62 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 67 */   public Resource getResourceType() { return this.terrain.getResource(); }
/*    */ 
/*    */   
/*    */   public int harvest(int prob, Player p) {
/* 71 */     if (this.u.getPlayer() == null || p.equals(this.u.getPlayer())) {
/* 72 */       if (prob == this.harvestProb) {
/* 73 */         return 1;
/*    */       }
/* 75 */       return 0;
/*    */     } 
/*    */     
/* 78 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 83 */   public void floodTile() { this.terrain = Terrain.WATER; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 88 */   public int getProb() { return this.harvestProb; }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 92 */     return "Prob: " + this.harvestProb + ", Resource Type: " + 
/* 93 */       this.terrain.getResource() + "\n";
/*    */   }
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\terrain\Tile.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */