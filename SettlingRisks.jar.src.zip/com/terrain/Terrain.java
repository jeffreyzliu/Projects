/*    */ package com.terrain;
/*    */ 
/*    */ import com.resource.Resource;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ public static enum Terrain
/*    */ {
/* 12 */   PLAINS("plains"), PASTURE("pasture"), FOREST("forest"), MOUNTAIN("mountain"), HILLS(
/* 13 */     "hills"), WATER("water");
/*    */   
/*    */   protected BufferedImage sprite;
/*    */   
/*    */   protected Resource resource;
/*    */   protected Location loc;
/*    */   
/*    */   Terrain(String name) {
/*    */     try {
/* 22 */       this.sprite = ImageIO.read(getClass().getResource("/com/terrain/" + name + ".jpg"));
/* 23 */     } catch (IOException iOException) {}
/*    */ 
/*    */     
/* 26 */     if (name.equals("plains")) {
/* 27 */       this.resource = Resource.GRAIN;
/* 28 */     } else if (name.equals("pasture")) {
/* 29 */       this.resource = Resource.WOOL;
/* 30 */     } else if (name.equals("forest")) {
/* 31 */       this.resource = Resource.LUMBER;
/* 32 */     } else if (name.equals("mountain")) {
/* 33 */       this.resource = Resource.ORE;
/* 34 */     } else if (name.equals("hills")) {
/* 35 */       this.resource = Resource.STONE;
/*    */     } else {
/* 37 */       this.resource = null;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 43 */   public void setLocation(Location loc) { this.loc = loc; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 49 */   public BufferedImage getSprite() { return this.sprite; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 55 */   public Location getLocation() { return this.loc; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 61 */   public Resource getResource() { return this.resource; }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Terrain getRandomTerrain() {
/* 67 */     i = (int)(Math.random() * values().length);
/* 68 */     if (i == 5) return getRandomTerrain(); 
/* 69 */     return values()[i];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Terrain getRandomTerrain(Terrain t, double delta) {
/* 75 */     double i = 1.0D / values().length;
/* 76 */     double r = Math.random();
/* 77 */     if (r < i + delta) {
/* 78 */       return t;
/*    */     }
/* 80 */     i = r * Math.pow(i, -1.0D);
/* 81 */     if ((int)i == 5) return t; 
/* 82 */     return values()[(int)i];
/*    */   }
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\terrain\Terrain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */