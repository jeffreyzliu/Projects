/*      */ package com.assets;
/*      */ 
/*      */ import com.resource.Resource;
/*      */ import com.structure.Structure;
/*      */ import com.terrain.Location;
/*      */ import com.terrain.Terrain;
/*      */ import com.terrain.Tile;
/*      */ import com.units.Unit;
/*      */ import java.awt.Color;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Image;
/*      */ import java.awt.Point;
/*      */ import java.awt.Polygon;
/*      */ import java.awt.Shape;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.KeyListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.MouseListener;
/*      */ import java.awt.event.MouseMotionListener;
/*      */ import java.awt.geom.AffineTransform;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.IOException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.HashMap;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JOptionPane;
/*      */ 
/*      */ 
/*      */ public class World
/*      */   implements KeyListener, MouseListener, MouseMotionListener
/*      */ {
/*      */   private Tile[][] map;
/*      */   private int mapWidth;
/*      */   private int mapHeight;
/*      */   private int dimX;
/*      */   private int dimY;
/*      */   private int x;
/*      */   private int y;
/*      */   private int mouseX;
/*      */   private int mouseY;
/*      */   private Player[] players;
/*      */   
/*      */   public World(int mapWidth, int mapHeight, int dimX, int dimY, int x, int y, String[] players) {
/*   48 */     this.gLength = 75;
/*   49 */     this.scrollSpeed = 75;
/*   50 */     this
/*   51 */       .colors = new Color[] { Color.RED, Color.BLUE, Color.YELLOW, Color.GREEN };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   60 */     this.turn = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   65 */     this.mapWidth = mapWidth;
/*   66 */     this.mapHeight = mapHeight;
/*   67 */     this.map = new Tile[mapWidth][mapHeight];
/*   68 */     this.dimX = dimX;
/*   69 */     this.dimY = dimY;
/*   70 */     this.x = x;
/*   71 */     this.y = y;
/*      */     
/*   73 */     (new Unit()).loadGraphics();
/*   74 */     Structure.SETTLEMENT.init();
/*   75 */     Structure.CITY.init();
/*      */     
/*   77 */     this.players = new Player[players.length];
/*   78 */     for (i = 0; i < players.length; i++) {
/*   79 */       this.players[i] = new Player(players[i]);
/*      */     }
/*      */     
/*   82 */     for (i = 0; i < mapWidth; i++) {
/*   83 */       this.map[i][0] = new Tile(new Location(i, false));
/*      */     }
/*   85 */     for (i = 0; i < mapWidth; i++) {
/*   86 */       double delta = 0.5D;
/*   87 */       for (int j = 1; j < mapHeight; j++) {
/*   88 */         Terrain toAdd = Terrain.getRandomTerrain(
/*   89 */             this.map[i][j - 1].getTerrain(), delta);
/*   90 */         if (toAdd.getSprite().equals(
/*   91 */             this.map[i][j - 1].getTerrain().getSprite()))
/*   92 */           delta--; 
/*   93 */         this.map[i][j] = new Tile(toAdd, new Location(i, j));
/*      */       } 
/*      */     } 
/*   96 */     riverGen();
/*      */     
/*   98 */     this.buttonSprites = new HashMap(); byte b; int k; Color[] arrayOfColor;
/*   99 */     for (k = arrayOfColor = this.colors.length, b = 0; b < k; ) { Color c = arrayOfColor[b];
/*  100 */       loadButton(c, "BuyRoad");
/*  101 */       loadButton(c, "BuySettlement");
/*  102 */       loadButton(c, "BuyCity");
/*  103 */       loadButton(c, "BuyUnit");
/*  104 */       loadButton(c, "Trade");
/*  105 */       loadButton(c, "EndTurn");
/*  106 */       loadButton(c, "BuyRoadShiny");
/*  107 */       loadButton(c, "BuySettlementShiny");
/*  108 */       loadButton(c, "BuyCityShiny");
/*  109 */       loadButton(c, "BuyUnitShiny");
/*  110 */       loadButton(c, "TradeShiny");
/*  111 */       loadButton(c, "EndTurnShiny"); b++; }
/*      */     
/*  113 */     loadPopup("RoadRes");
/*  114 */     loadPopup("SettlementRes");
/*  115 */     loadPopup("CityRes");
/*  116 */     loadPopup("UnitRes");
/*  117 */     loadPopup("NotEnoughRes");
/*      */     
/*  119 */     this.roadImages = new BufferedImage[2];
/*      */     try {
/*  121 */       this.roadImages[0] = ImageIO.read(getClass().getResource(
/*  122 */             "/com/assets/road/road-v.png"));
/*  123 */       this.roadImages[1] = ImageIO.read(getClass().getResource(
/*  124 */             "/com/assets/road/road-h.png"));
/*  125 */       this.toolbar = ImageIO.read(getClass().getResource(
/*  126 */             "/com/assets/background/toolbar.png"));
/*  127 */     } catch (IOException i) {
/*  128 */       IOException e; System.out.println("Failed");
/*      */     } 
/*      */     
/*  131 */     this.state = "";
/*  132 */     this.cursor = "";
/*      */   }
/*      */   private String state; private String cursor; private final int gLength = 75; private final int scrollSpeed = 75; private final Color[] colors; private Location from; private HashMap<String, BufferedImage> buttonSprites; private BufferedImage[] roadImages; private BufferedImage toolbar;
/*      */   int turn;
/*      */   
/*      */   private void loadButton(Color c, String name) {
/*      */     try {
/*  139 */       this.buttonSprites.put(
/*  140 */           String.valueOf(c.getRGB()) + "_" + name, 
/*  141 */           ImageIO.read(getClass().getResource(
/*  142 */               "/com/assets/button/" + c.getRGB() + "_" + name + 
/*  143 */               ".png")));
/*  144 */     } catch (IOException e) {
/*  145 */       System.out.println("failed");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void loadPopup(String name) {
/*  152 */     System.out.println(name);
/*      */     try {
/*  154 */       this.buttonSprites.put(
/*  155 */           name, 
/*  156 */           ImageIO.read(getClass().getResource(
/*  157 */               "/com/assets/button/" + name + ".png")));
/*  158 */     } catch (IOException e) {
/*  159 */       System.out.println("failed");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void riverGen() {
/*  165 */     int riverX = 0;
/*  166 */     int riverY = 0;
/*  167 */     int destination = 0;
/*  168 */     int flowC = 0;
/*  169 */     int counter = 0;
/*  170 */     int dir = (int)(4.0D * Math.random());
/*  171 */     if (dir == 0) {
/*  172 */       riverX = (int)(this.mapWidth * Math.random());
/*  173 */       riverY = this.mapHeight - 1;
/*  174 */       destination = -1;
/*  175 */       flowC = -1;
/*      */     } 
/*  177 */     if (dir == 1) {
/*  178 */       riverX = 0;
/*  179 */       riverY = (int)(this.mapHeight * Math.random());
/*  180 */       destination = this.mapWidth;
/*  181 */       flowC = 1;
/*      */     } 
/*  183 */     if (dir == 2) {
/*  184 */       riverX = (int)(this.mapWidth * Math.random());
/*  185 */       riverY = 0;
/*  186 */       destination = this.mapHeight;
/*  187 */       flowC = 1;
/*      */     } 
/*  189 */     if (dir == 3) {
/*  190 */       riverX = this.mapWidth - 1;
/*  191 */       riverY = (int)(this.mapHeight * Math.random());
/*  192 */       destination = -1;
/*  193 */       flowC = -1;
/*      */     } 
/*  195 */     System.out.println(dir);
/*  196 */     if (dir == 0 || dir == 2) {
/*  197 */       while (Math.abs(riverY - destination) > 0 && counter < 999) {
/*  198 */         if (riverX >= 0 && riverX <= this.mapWidth - 1 && riverY >= 0 && riverY <= this.mapHeight - 1) {
/*  199 */           this.map[riverX][riverY].floodTile();
/*      */         }
/*  201 */         double r = Math.random();
/*  202 */         if (r < 0.1D) {
/*  203 */           riverX++;
/*  204 */           riverY -= 1 * flowC;
/*  205 */         } else if (r < 0.2D) {
/*  206 */           riverX++;
/*  207 */         } else if (r < 0.3D) {
/*  208 */           riverX--;
/*  209 */         } else if (r < 0.4D) {
/*  210 */           riverX--;
/*  211 */           riverY -= 1 * flowC;
/*  212 */         } else if (r < 0.6D) {
/*  213 */           riverX++;
/*  214 */           riverY += 1 * flowC;
/*  215 */         } else if (r < 0.8D) {
/*  216 */           riverX--;
/*  217 */           riverY += 1 * flowC;
/*      */         } else {
/*  219 */           riverY += 1 * flowC;
/*      */         } 
/*  221 */         counter++;
/*      */       } 
/*      */     } else {
/*  224 */       while (Math.abs(riverX - destination) > 0 && counter < 999) {
/*  225 */         if (riverX >= 0 && riverX <= this.mapWidth - 1 && riverY >= 0 && riverY <= this.mapHeight - 1) {
/*  226 */           this.map[riverX][riverY].floodTile();
/*      */         }
/*  228 */         double r = Math.random();
/*  229 */         if (r < 0.1D) {
/*  230 */           riverY++;
/*  231 */           riverX -= 1 * flowC;
/*  232 */         } else if (r < 0.2D) {
/*  233 */           riverY++;
/*  234 */         } else if (r < 0.3D) {
/*  235 */           riverY--;
/*  236 */         } else if (r < 0.4D) {
/*  237 */           riverY--;
/*  238 */           riverX -= 1 * flowC;
/*  239 */         } else if (r < 0.6D) {
/*  240 */           riverY++;
/*  241 */           riverX += 1 * flowC;
/*  242 */         } else if (r < 0.8D) {
/*  243 */           riverY--;
/*  244 */           riverX += 1 * flowC;
/*      */         } else {
/*  246 */           riverX += 1 * flowC;
/*      */         } 
/*  248 */         counter++;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void keyPressed(KeyEvent e) {
/*  255 */     if (e.getKeyCode() == 38)
/*  256 */       moveCamera(0, -75); 
/*  257 */     if (e.getKeyCode() == 40)
/*  258 */       moveCamera(0, 75); 
/*  259 */     if (e.getKeyCode() == 37)
/*  260 */       moveCamera(-75, 0); 
/*  261 */     if (e.getKeyCode() == 39) {
/*  262 */       moveCamera(75, 0);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void keyReleased(KeyEvent e) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void tick() {
/*  274 */     if (this.state.equals("trading") && !getCurrPlayer().getTrader().isShowing()) {
/*  275 */       this.state = "";
/*      */ 
/*      */       
/*  278 */       getCurrPlayer().getTrader().finishTrade();
/*      */     }  byte b; int i;
/*      */     Player[] arrayOfPlayer;
/*  281 */     for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  282 */       for (Location loc : p.getUnits().keySet()) {
/*  283 */         if (((Unit)p.getUnits().get(loc)).getAmount() < 1) {
/*  284 */           p.getUnits().remove(loc);
/*      */         }
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   
/*      */   public void render(Graphics g) {
/*  292 */     g.setFont(new Font("Garamond", true, 14));
/*      */     
/*  294 */     for (i = 0; i < this.mapWidth; i++) {
/*  295 */       for (int j = 0; j < this.mapHeight; j++) {
/*  296 */         g.drawImage(this.map[i][j].getSprite(), -this.x + i * 75, -this.y + j * 
/*  297 */             75, 75, 75, null);
/*      */       }
/*      */     } 
/*      */     try {
/*  301 */       for (int i = 0; i < this.players.length; i++) {
/*  302 */         g.setColor(this.colors[i]);
/*  303 */         for (Location loc : this.players[i].getUnits().keySet()) {
/*  304 */           g.drawRect(loc.getX() * 75 - this.x, loc.getY() * 75 - 
/*  305 */               this.y, 75, 75);
/*      */         }
/*      */       } 
/*  308 */     } catch (ConcurrentModificationException i) {
/*      */       ConcurrentModificationException concurrentModificationException;
/*      */     } 
/*      */     
/*  312 */     renderRoads(g);
/*      */     
/*  314 */     renderUnits(g);
/*      */     
/*  316 */     g.setColor(new Color('Ò', '´', ''));
/*  317 */     for (i = 0; i < this.mapWidth; i++) {
/*  318 */       for (int j = 0; j < this.mapHeight; j++) {
/*  319 */         if (this.map[i][j].getTerrain() != Terrain.WATER) {
/*  320 */           g.drawOval(-this.x + i * 75 + 23, -this.y + j * 75 + 20, 
/*  321 */               30, 30);
/*      */         }
/*      */       } 
/*      */     } 
/*  325 */     g.setColor(Color.WHITE);
/*  326 */     for (int i = 0; i < this.mapWidth; i++) {
/*  327 */       for (int j = 0; j < this.mapHeight; j++) {
/*  328 */         if (this.map[i][j].getTerrain() != Terrain.WATER) {
/*  329 */           if (this.map[i][j].getProb() > 9) {
/*  330 */             g.drawString(this.map[i][j].getProb(), -this.x + i * 75 + 
/*  331 */                 32, -this.y + j * 75 + 40);
/*      */           } else {
/*  333 */             g.drawString(this.map[i][j].getProb(), -this.x + i * 75 + 
/*  334 */                 35, -this.y + j * 75 + 40);
/*      */           } 
/*      */         }
/*      */       } 
/*      */     } 
/*  339 */     renderStructures(g);
/*      */ 
/*      */     
/*  342 */     g.setColor(Color.WHITE);
/*  343 */     g.fillRect(0, this.dimY, 1200, this.dimY);
/*  344 */     g.drawImage(this.toolbar, 0, this.dimY, 1200, this.dimY, null);
/*      */ 
/*      */ 
/*      */     
/*  348 */     g.drawString(getCurrPlayer().getName(), 25, 750);
/*      */     
/*  350 */     renderResources(g);
/*  351 */     renderButtons(g);
/*  352 */     renderNumber(g);
/*      */     
/*  354 */     renderCursor(g);
/*      */     
/*  356 */     g.dispose();
/*      */     
/*  358 */     if (this.state.equals("trading")) {
/*  359 */       getCurrPlayer().getTrader().render();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void renderCursor(Graphics g) {
/*      */     String str;
/*  366 */     switch ((str = this.cursor).hashCode()) { case 3053931: if (!str.equals("city")) {
/*      */           break;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  372 */         g.drawImage(Structure.CITY.getSprite(), this.mouseX - 20, this.mouseY - 20, 
/*  373 */             50, 50, null); return;
/*      */       case 3505952:
/*      */         if (!str.equals("road"))
/*  376 */           break;  g.drawImage(this.roadImages[0], this.mouseX - 20, this.mouseY - 20, 50, 50, null); return;
/*      */       case 3594628:
/*      */         if (!str.equals("unit"))
/*  379 */           break;  g.drawImage((new Unit()).getSprite(), this.mouseX - 20, this.mouseY - 20, 75, 
/*  380 */             75, null); return;
/*      */       case 73828649:
/*      */         if (!str.equals("settlement"))
/*  383 */           break;  g.drawImage(Structure.SETTLEMENT.getSprite(), this.mouseX - 20, this.mouseY - 20, 50, 50, null); return; }  renderAttackArrow(g);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void renderButtons(Graphics g) {
/*  390 */     if (pointInCircle(250, 765, 50, this.mouseX, this.mouseY)) {
/*  391 */       g.drawImage(
/*  392 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  393 */             "_BuyRoadShiny"), 200, 715, 100, 100, null);
/*  394 */       g.drawImage((Image)this.buttonSprites.get("RoadRes"), 200, 575, 169, 130, null);
/*      */     } else {
/*  396 */       g.drawImage(
/*  397 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  398 */             "_BuyRoad"), 200, 715, 100, 100, null);
/*      */     } 
/*  400 */     if (pointInCircle(365, 765, 50, this.mouseX, this.mouseY)) {
/*  401 */       g.drawImage(
/*  402 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  403 */             "_BuySettlementShiny"), 315, 715, 100, 100, null);
/*  404 */       g.drawImage((Image)this.buttonSprites.get("SettlementRes"), 315, 575, 169, 130, 
/*  405 */           null);
/*      */     } else {
/*  407 */       g.drawImage(
/*  408 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  409 */             "_BuySettlement"), 315, 715, 100, 100, null);
/*      */     } 
/*  411 */     if (pointInCircle(480, 765, 50, this.mouseX, this.mouseY)) {
/*  412 */       g.drawImage(
/*  413 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  414 */             "_BuyCityShiny"), 430, 715, 100, 100, null);
/*  415 */       g.drawImage((Image)this.buttonSprites.get("CityRes"), 430, 575, 169, 130, null);
/*      */     } else {
/*  417 */       g.drawImage(
/*  418 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  419 */             "_BuyCity"), 430, 715, 100, 100, null);
/*      */     } 
/*  421 */     if (pointInCircle(595, 765, 50, this.mouseX, this.mouseY)) {
/*  422 */       g.drawImage(
/*  423 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  424 */             "_BuyUnitShiny"), 545, 715, 100, 100, null);
/*  425 */       g.drawImage((Image)this.buttonSprites.get("UnitRes"), 545, 575, 169, 130, null);
/*      */     } else {
/*  427 */       g.drawImage(
/*  428 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  429 */             "_BuyUnit"), 545, 715, 100, 100, null);
/*      */     } 
/*  431 */     if (pointInCircle(710, 765, 50, this.mouseX, this.mouseY)) {
/*  432 */       g.drawImage(
/*  433 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  434 */             "_TradeShiny"), 660, 715, 100, 100, null);
/*      */     } else {
/*  436 */       g.drawImage(
/*  437 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  438 */             "_Trade"), 660, 715, 100, 100, null);
/*      */     } 
/*  440 */     if (this.mouseX < 1100 && this.mouseX > 1000 && this.mouseY < 800 && this.mouseY > 750) {
/*  441 */       g.drawImage(
/*  442 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  443 */             "_EndTurnShiny"), 1000, 750, 100, 50, null);
/*      */     } else {
/*  445 */       g.drawImage(
/*  446 */           (Image)this.buttonSprites.get(String.valueOf(this.colors[this.turn % this.players.length].getRGB()) + 
/*  447 */             "_EndTurn"), 1000, 750, 100, 50, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  455 */   private boolean pointInCircle(int centerX, int centerY, int radius, int x, int y) { return (Math.pow((centerX - x), 2.0D) + Math.pow((centerY - y), 2.0D) <= 
/*  456 */       Math.pow(radius, 2.0D)); }
/*      */ 
/*      */ 
/*      */   
/*      */   public void buySettlement() {
/*  461 */     Player p = getCurrPlayer();
/*  462 */     if (p.checkStruct(Structure.SETTLEMENT)) {
/*  463 */       this.state = "buySettlement";
/*  464 */       this.cursor = "settlement";
/*      */     } else {
/*  466 */       JOptionPane.showMessageDialog(new JFrame(), "Not enough resources", 
/*  467 */           "Purchase Error", 0);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void buyCity() {
/*  472 */     Player p = getCurrPlayer();
/*  473 */     if (p.checkStruct(Structure.CITY)) {
/*  474 */       this.state = "buyCity";
/*  475 */       this.cursor = "city";
/*      */     } else {
/*  477 */       JOptionPane.showMessageDialog(new JFrame(), "Not enough resources", 
/*  478 */           "Purchase Error", 0);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void buyUnit() {
/*  483 */     Player p = getCurrPlayer();
/*  484 */     if (p.checkUnit()) {
/*  485 */       this.state = "buyUnit";
/*  486 */       this.cursor = "unit";
/*      */     } else {
/*  488 */       JOptionPane.showMessageDialog(new JFrame(), "Not enough resources", 
/*  489 */           "Purchase Error", 0);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void buyRoad() {
/*  494 */     Player p = getCurrPlayer();
/*  495 */     if (p.checkRoad()) {
/*  496 */       this.state = "buyRoad";
/*  497 */       this.cursor = "road";
/*      */     } else {
/*  499 */       JOptionPane.showMessageDialog(new JFrame(), "Not enough resources", 
/*  500 */           "Purchase Error", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void trade() {
/*  506 */     getCurrPlayer().trade();
/*  507 */     this.state = "trading";
/*      */   }
/*      */ 
/*      */   
/*      */   public void renderAttackArrow(Graphics g) {
/*  512 */     if (this.from != null) {
/*  513 */       int cX = this.from.getX() * 75 - this.x + 37;
/*  514 */       int cY = this.from.getY() * 75 - this.y + 37;
/*  515 */       double angle = Math.atan2((this.mouseY - cY), (cX - this.mouseX));
/*  516 */       angle -= 1.5707963267948966D;
/*  517 */       g.setColor(Color.RED);
/*      */       
/*  519 */       ((Graphics2D)g).fill(createArrowShape(new Point(cX, cY), 
/*  520 */             new Point((int)(100.0D * Math.sin(angle)) + cX, 
/*  521 */               (int)(100.0D * Math.cos(angle) + cY))));
/*      */     } 
/*      */   }
/*      */   
/*      */   public void renderStructures(Graphics g) {
/*  526 */     for (int i = 0; i < this.players.length; i++) {
/*  527 */       Player p = this.players[i];
/*  528 */       HashMap<Location, Structure> tmp = p.getStruct();
/*      */       try {
/*  530 */         for (Location loc : tmp.keySet()) {
/*  531 */           g.drawImage(((Structure)tmp.get(loc)).getSprite(), -this.x + loc.getX() * 
/*  532 */               75 - 25, -this.y + loc.getY() * 75 - 25, 50, 
/*  533 */               50, null);
/*      */           
/*  535 */           g.drawImage(((Structure)tmp.get(loc)).getOutline(this.colors[i]), 
/*  536 */               -this.x + loc.getX() * 75 - 25, -this.y + loc.getY() * 
/*  537 */               75 - 25, 50, 50, null);
/*      */         } 
/*  539 */       } catch (Exception e) {
/*  540 */         System.out.println("try again");
/*      */       } 
/*      */     } 
/*      */   } public void renderRoads(Graphics g) {
/*      */     byte b;
/*      */     int i;
/*      */     Player[] arrayOfPlayer;
/*  547 */     for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  548 */       ArrayList<Location[]> tmp = p.getRoads();
/*  549 */       for (Location[] loc : tmp) {
/*  550 */         int dir = loc[0].getDirection(loc[1]);
/*  551 */         if (dir == 180) {
/*  552 */           g.drawImage(this.roadImages[0], 
/*  553 */               loc[0].getX() * 75 - 25 - this.x, loc[0].getY() * 
/*  554 */               75 - 62 - this.y, 50, 50, null);
/*      */         }
/*  556 */         if (dir == 90) {
/*  557 */           g.drawImage(this.roadImages[1], 
/*  558 */               loc[0].getX() * 75 + 12 - this.x, loc[0].getY() * 
/*  559 */               75 - 25 - this.y, 50, 50, null);
/*      */         }
/*      */       } 
/*      */       b++; }
/*      */   
/*      */   }
/*      */   
/*      */   public void renderResources(Graphics g) {
/*  567 */     g.setColor(Color.WHITE);
/*  568 */     int yVal = 700; byte b; int i; Resource[] arrayOfResource;
/*  569 */     for (i = arrayOfResource = Resource.values().length, b = 0; b < i; ) { Resource r = arrayOfResource[b];
/*  570 */       g.drawImage(r.getIcon(), 100, yVal, 30, 30, null);
/*  571 */       g.setColor(Color.BLACK);
/*  572 */       g.drawString(this.players[this.turn % this.players.length].getR(r), 150, 
/*  573 */           yVal + 20);
/*  574 */       yVal += 30;
/*      */       b++; }
/*      */      } public void renderUnits(Graphics g) { try {
/*      */       byte b;
/*      */       int i;
/*      */       Player[] arrayOfPlayer;
/*  580 */       for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  581 */         HashMap<Location, Unit> mp = p.getUnits();
/*  582 */         for (Location loc : mp.keySet())
/*  583 */           g.drawImage(((Unit)mp.get(loc)).getSprite(), loc.getX() * 75 - 
/*  584 */               5 - this.x, loc.getY() * 75 + 8 - this.y, 75, 75, null); 
/*      */         b++; }
/*      */     
/*  587 */     } catch (Exception exception) {} }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void renderNumber(Graphics g) {
/*  594 */     int gridX = (this.mouseX + this.x) / 75;
/*  595 */     int gridY = (this.mouseY + this.y) / 75;
/*  596 */     g.setColor(Color.WHITE);
/*      */     try {
/*  598 */       if (this.map[gridX][gridY].getUnit().getAmount() != 0) {
/*  599 */         g.drawString(
/*  600 */             String.valueOf(this.map[gridX][gridY].getUnit().getAmount()), 
/*  601 */             gridX * 75 + 10 - this.x, gridY * 75 + 15 - this.y);
/*      */       }
/*  603 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveCamera(int deltaX, int deltaY) {
/*  610 */     int newX = this.x + deltaX;
/*  611 */     int newY = this.y + deltaY;
/*  612 */     if (newX >= 0 && newX + this.dimX <= this.mapWidth * 75)
/*  613 */       this.x = newX; 
/*  614 */     if (newY >= 0 && newY + this.dimY <= this.mapHeight * 75) {
/*  615 */       this.y = newY;
/*      */     }
/*      */   }
/*      */   
/*      */   public static Shape createArrowShape(Point fromPt, Point toPt) {
/*  620 */     Polygon arrowPolygon = new Polygon();
/*  621 */     arrowPolygon.addPoint(-6, 1);
/*  622 */     arrowPolygon.addPoint(3, 1);
/*  623 */     arrowPolygon.addPoint(3, 3);
/*  624 */     arrowPolygon.addPoint(6, 0);
/*  625 */     arrowPolygon.addPoint(3, -3);
/*  626 */     arrowPolygon.addPoint(3, -1);
/*  627 */     arrowPolygon.addPoint(-6, -1);
/*      */     
/*  629 */     Point midPoint = midpoint(fromPt, toPt);
/*      */     
/*  631 */     double rotate = Math.atan2((toPt.y - fromPt.y), (toPt.x - fromPt.x));
/*      */     
/*  633 */     AffineTransform transform = new AffineTransform();
/*  634 */     transform.translate(midPoint.x, midPoint.y);
/*  635 */     double ptDistance = fromPt.distance(toPt);
/*  636 */     double scale = ptDistance / 12.0D;
/*      */     
/*  638 */     transform.scale(scale, scale);
/*  639 */     transform.rotate(rotate);
/*      */     
/*  641 */     return transform.createTransformedShape(arrowPolygon);
/*      */   }
/*      */   
/*      */   private static Point midpoint(Point p1, Point p2) {
/*  645 */     return new Point((int)((p1.x + p2.x) / 2.0D), 
/*  646 */         (int)((p1.y + p2.y) / 2.0D));
/*      */   }
/*      */   
/*      */   public void keyTyped(KeyEvent k) {
/*  650 */     if (k.getKeyChar() == '\033') {
/*  651 */       this.cursor = "";
/*  652 */       this.state = "";
/*  653 */       this.from = null;
/*  654 */       System.out.println("escape");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void mouseClicked(MouseEvent e) {
/*  660 */     int gridY, gridX, absY, absX, mouseX = e.getX();
/*  661 */     int mouseY = e.getY(); String str;
/*  662 */     switch ((str = this.state).hashCode()) { case -1381370801: if (!str.equals("buySettlement"))
/*      */           break; 
/*  664 */         mouseX = e.getX();
/*  665 */         mouseY = e.getY();
/*      */         
/*  667 */         if (mouseY < this.dimY)
/*  668 */         { int absX = mouseX + this.x;
/*  669 */           int absY = mouseY + this.y;
/*  670 */           absX += 25;
/*  671 */           absY += 25;
/*  672 */           int gridX = absX / 75;
/*  673 */           int gridY = absY / 75;
/*      */           
/*  675 */           System.out.println(String.valueOf(gridX) + " , " + gridY);
/*      */           
/*  677 */           boolean valid = false;
/*      */           
/*  679 */           if (this.turn / this.players.length < 1)
/*  680 */             valid = true;  byte b;
/*      */           int i;
/*      */           Player[] arrayOfPlayer;
/*  683 */           for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  684 */             if (p.validLoc(new Location(gridX, gridY))) {
/*  685 */               valid = true;
/*      */               break;
/*      */             } 
/*      */             b++; }
/*      */           
/*  690 */           for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  691 */             if (p.buildingAtLoc(new Location(gridX, gridY))) {
/*  692 */               valid = false; break;
/*      */             } 
/*      */             b++; }
/*      */           
/*  696 */           if (valid)
/*  697 */           { Structure toAdd = Structure.SETTLEMENT;
/*  698 */             toAdd.chooseColor(this.colors[this.turn % this.players.length]);
/*  699 */             ArrayList<Tile> surroundingTiles = new ArrayList<Tile>();
/*  700 */             for (int changeX = 0; changeX <= 1; changeX++) {
/*  701 */               for (int changeY = 0; changeY <= 1; changeY++) {
/*  702 */                 if (changeX + gridX < this.mapWidth && 
/*  703 */                   changeY + gridY < this.mapHeight) {
/*  704 */                   surroundingTiles
/*  705 */                     .add(this.map[changeX + gridX - 1][changeY + 
/*  706 */                         gridY - 1]);
/*      */                 }
/*      */               } 
/*      */             } 
/*  710 */             getCurrPlayer().addOwnedTiles(surroundingTiles);
/*  711 */             getCurrPlayer().addBuilding(new Location(gridX, gridY), 
/*  712 */                 toAdd);
/*  713 */             System.out.println("add1");
/*  714 */             this.state = "";
/*  715 */             this.cursor = ""; }  }  return;
/*      */       case -1067367135: if (!str.equals("trading"))
/*      */           break;  return;
/*      */       case 244504849:
/*      */         if (!str.equals("buyCity"))
/*  720 */           break;  mouseX = e.getX();
/*  721 */         mouseY = e.getY();
/*      */         
/*  723 */         if (mouseY < this.dimY) {
/*  724 */           int absX = mouseX + this.x;
/*  725 */           int absY = mouseY + this.y;
/*  726 */           absX += 25;
/*  727 */           absY += 25;
/*  728 */           int gridX = absX / 75;
/*  729 */           int gridY = absY / 75;
/*      */           
/*  731 */           System.out.println(String.valueOf(gridX) + " , " + gridY);
/*      */           
/*  733 */           boolean valid = false; byte b; int i; Player[] arrayOfPlayer;
/*  734 */           for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  735 */             if (p.validLoc(new Location(gridX, gridY))) {
/*  736 */               valid = true; break;
/*      */             } 
/*      */             b++; }
/*      */           
/*  740 */           if (valid)
/*  741 */             if (getCurrPlayer().settlementAtLoc(
/*  742 */                 new Location(gridX, gridY))) {
/*  743 */               Structure toAdd = Structure.CITY;
/*  744 */               toAdd.chooseColor(this.colors[this.turn % this.players.length]);
/*  745 */               ArrayList<Tile> surroundingTiles = new ArrayList<Tile>();
/*  746 */               for (int changeX = 0; changeX <= 1; changeX++) {
/*  747 */                 for (int changeY = 0; changeY <= 1; changeY++) {
/*  748 */                   if (changeX + gridX < this.mapWidth && 
/*  749 */                     changeY + gridY < this.mapHeight) {
/*  750 */                     surroundingTiles.add(this.map[changeX + gridX - 
/*  751 */                           1][changeY + gridY - 1]);
/*  752 */                     System.out.println("(" + (changeX + gridX) + 
/*  753 */                         ", " + (changeY + gridY) + ")");
/*      */                   } 
/*      */                 } 
/*      */               } 
/*  757 */               getCurrPlayer().addOwnedTiles(surroundingTiles);
/*  758 */               getCurrPlayer().addBuilding(new Location(gridX, gridY), 
/*  759 */                   toAdd);
/*  760 */               this.state = "";
/*  761 */               this.cursor = "";
/*      */             } else {
/*  763 */               JOptionPane.showMessageDialog(new JFrame(), 
/*  764 */                   "Please select a settlement to upgrade", 
/*  765 */                   "Selection Error", 0);
/*      */             }  
/*      */         }  return;
/*      */       case 244956870:
/*      */         if (!str.equals("buyRoad"))
/*      */           break; 
/*  771 */         mouseX = e.getX();
/*  772 */         mouseY = e.getY();
/*      */         
/*  774 */         if (mouseY < this.dimY) {
/*  775 */           int absX = mouseX + this.x;
/*  776 */           int absY = mouseY + this.y;
/*  777 */           int gridX = absX / 75;
/*  778 */           int gridY = absY / 75;
/*  779 */           absX -= gridX * 75;
/*  780 */           absY -= gridY * 75;
/*  781 */           int r = -absX + 75;
/*  782 */           int s = absX;
/*  783 */           gridY++;
/*  784 */           if (absY > s) {
/*  785 */             if (absY > r) {
/*      */               
/*  787 */               System.out.println("uh");
/*  788 */               boolean valid = false;
/*  789 */               System.out.println("X: " + gridX + ", Y: " + gridY); byte b; int i; Player[] arrayOfPlayer;
/*  790 */               for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  791 */                 if (p.validLoc(new Location(gridX, gridY)) || 
/*  792 */                   p.validLoc(new Location(gridX + 1, gridY))) {
/*  793 */                   valid = true; break;
/*      */                 } 
/*      */                 b++; }
/*      */               
/*  797 */               if (valid) {
/*  798 */                 getCurrPlayer().addRoad(new Location(gridX, gridY), 
/*  799 */                     new Location(gridX + 1, gridY));
/*  800 */                 this.state = "";
/*  801 */                 this.cursor = "";
/*      */               }
/*      */             
/*      */             } else {
/*      */               
/*  806 */               boolean valid = false; byte b; int i; Player[] arrayOfPlayer;
/*  807 */               for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  808 */                 if (p.validLoc(new Location(gridX, gridY)) || 
/*  809 */                   p.validLoc(new Location(gridX, gridY - 1))) {
/*  810 */                   valid = true; break;
/*      */                 } 
/*      */                 b++; }
/*      */               
/*  814 */               if (valid) {
/*  815 */                 getCurrPlayer().addRoad(new Location(gridX, gridY), 
/*  816 */                     new Location(gridX, gridY - 1));
/*  817 */                 this.state = "";
/*  818 */                 this.cursor = "";
/*      */               }
/*      */             
/*      */             } 
/*  822 */           } else if (absY > r) {
/*      */             
/*  824 */             boolean valid = false; byte b; int i; Player[] arrayOfPlayer;
/*  825 */             for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  826 */               if (p.validLoc(new Location(gridX + 1, gridY)) || 
/*  827 */                 p.validLoc(new Location(gridX + 1, 
/*  828 */                     gridY - 1))) {
/*  829 */                 valid = true; break;
/*      */               } 
/*      */               b++; }
/*      */             
/*  833 */             if (valid) {
/*  834 */               getCurrPlayer().addRoad(
/*  835 */                   new Location(gridX + 1, gridY), 
/*  836 */                   new Location(gridX + 1, gridY - 1));
/*  837 */               this.state = "";
/*  838 */               this.cursor = "";
/*      */             } 
/*      */           } else {
/*      */             
/*  842 */             boolean valid = false; byte b; int i; Player[] arrayOfPlayer;
/*  843 */             for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  844 */               if (p.validLoc(new Location(gridX, gridY - 1)) || 
/*  845 */                 p.validLoc(new Location(gridX + 1, 
/*  846 */                     gridY - 1))) {
/*  847 */                 valid = true; break;
/*      */               } 
/*      */               b++; }
/*      */             
/*  851 */             if (valid) {
/*  852 */               getCurrPlayer().addRoad(
/*  853 */                   new Location(gridX, gridY - 1), 
/*  854 */                   new Location(gridX + 1, gridY - 1));
/*  855 */               this.state = "";
/*  856 */               this.cursor = "";
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 245045546:
/*      */         if (!str.equals("buyUnit")) {
/*      */           break;
/*      */         }
/*  866 */         absX = mouseX + this.x;
/*  867 */         absY = mouseY + this.y;
/*  868 */         gridX = absX / 75;
/*  869 */         gridY = absY / 75;
/*  870 */         System.out.println(this.map[gridX][gridY].getOwner());
/*  871 */         if (mouseY < this.dimY && getCurrPlayer().inOwnedTile(new Location(gridX, gridY))) {
/*  872 */           if (this.map[gridX][gridY].getOwner() == null) {
/*  873 */             getCurrPlayer().addUnit(new Location(gridX, gridY));
/*  874 */             this.map[gridX][gridY].addUnit((Unit)getCurrPlayer().getUnits()
/*  875 */                 .get(new Location(gridX, gridY)));
/*  876 */           } else if (this.map[gridX][gridY].getOwner().equals(
/*  877 */               getCurrPlayer())) {
/*  878 */             getCurrPlayer().addUnit(new Location(gridX, gridY));
/*      */           } 
/*      */         }
/*      */         
/*  882 */         if (!getCurrPlayer().checkUnit()) {
/*  883 */           this.state = "";
/*  884 */           this.cursor = "";
/*      */         } 
/*      */         return; }
/*      */     
/*  888 */     if (mouseX < 1100 && mouseX > 1000 && mouseY < 800 && mouseY > 750) {
/*  889 */       System.out.println("Turn ended");
/*  890 */       getCurrPlayer().reset();
/*      */       
/*  892 */       checkVictory();
/*      */ 
/*      */       
/*  895 */       this.turn++;
/*      */       
/*  897 */       if (this.turn / this.players.length != 0) {
/*  898 */         int prob = (new Dice()).resourceRoll(); Player[] arrayOfPlayer;
/*  899 */         for (gridY = arrayOfPlayer = this.players.length, gridX = 0; gridX < gridY; ) { Player p = arrayOfPlayer[gridX];
/*  900 */           p.harvest(prob); gridX++; }
/*      */         
/*  902 */         for (gridY = arrayOfPlayer = this.players.length, gridX = 0; gridX < gridY; ) { Player p = arrayOfPlayer[gridX];
/*  903 */           p.printSurrounding();
/*      */           gridX++; }
/*      */       
/*      */       } 
/*      */     } 
/*  908 */     if (pointInCircle(710, 765, 50, mouseX, mouseY)) {
/*  909 */       System.out.println("Trade");
/*  910 */       trade();
/*      */     } 
/*      */     
/*  913 */     if (pointInCircle(595, 765, 50, mouseX, mouseY)) {
/*  914 */       System.out.println("Buy Unit");
/*  915 */       buyUnit();
/*      */     } 
/*      */     
/*  918 */     if (pointInCircle(480, 765, 50, mouseX, mouseY)) {
/*  919 */       System.out.println("Buy City");
/*  920 */       buyCity();
/*      */     } 
/*      */     
/*  923 */     if (pointInCircle(365, 765, 50, mouseX, mouseY)) {
/*  924 */       System.out.println("Buy Settlement");
/*  925 */       buySettlement();
/*      */     } 
/*      */     
/*  928 */     if (pointInCircle(250, 765, 50, mouseX, mouseY)) {
/*  929 */       System.out.println("Buy Road");
/*  930 */       buyRoad();
/*      */     } 
/*      */     
/*  933 */     if (mouseY < 700) {
/*  934 */       int absX = mouseX + this.x;
/*  935 */       int absY = mouseY + this.y;
/*  936 */       int gridX = absX / 75;
/*  937 */       int gridY = absY / 75;
/*  938 */       if (this.from == null) {
/*  939 */         if (getCurrPlayer().getUnits().containsKey(
/*  940 */             new Location(gridX, gridY))) {
/*  941 */           this.from = new Location(gridX, gridY);
/*      */         }
/*      */       }
/*  944 */       else if (Math.abs(gridX - this.from.getX()) <= 1 && 
/*  945 */         Math.abs(gridY - this.from.getY()) <= 1) {
/*  946 */         attack(this.from, new Location(gridX, gridY));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void attack(Location from, Location to) {
/*      */     byte b;
/*      */     int i;
/*      */     Player[] arrayOfPlayer;
/*  956 */     for (i = arrayOfPlayer = this.players.length, b = 0; b < i; ) { Player p = arrayOfPlayer[b];
/*  957 */       if (p != getCurrPlayer())
/*  958 */         for (Location loc : p.getUnits().keySet()) {
/*  959 */           if (loc.equals(to)) {
/*  960 */             System.out.println("battle");
/*  961 */             int[] battleResult = (new Dice()).battle((
/*  962 */                 (Unit)getCurrPlayer().getUnits().get(from))
/*  963 */                 .getAvailable(), ((Unit)p.getUnits().get(to))
/*  964 */                 .getAmount());
/*  965 */             System.out.println("addATK");
/*  966 */             getCurrPlayer().addU(from, battleResult[0]);
/*  967 */             System.out.println("addDEF");
/*  968 */             p.addU(to, battleResult[1]);
/*      */             return;
/*      */           } 
/*      */         }  
/*      */       b++; }
/*      */     
/*  974 */     System.out.println("moving");
/*      */     
/*  976 */     getCurrPlayer().moveUnit(from, to);
/*      */     
/*  978 */     if (this.map[to.getX()][to.getY()].getUnit().getPlayer() == null)
/*  979 */       this.map[to.getX()][to.getY()].addUnit((Unit)getCurrPlayer().getUnits()
/*  980 */           .get(to)); 
/*      */   }
/*      */   
/*      */   public boolean checkVictory() {
/*  984 */     System.out.println(String.valueOf(getCurrPlayer().getName()) + " , " + getCurrPlayer().countVP());
/*  985 */     if (getCurrPlayer().countVP() >= 13) {
/*  986 */       JOptionPane.showMessageDialog(new JFrame(), "VICTORY for " + getCurrPlayer().getName(), 
/*  987 */           "Purchase Error", -1);
/*  988 */       return true;
/*      */     } 
/*  990 */     return false;
/*      */   }
/*      */ 
/*      */   
/*  994 */   public Player getCurrPlayer() { return this.players[this.turn % this.players.length]; }
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseMoved(MouseEvent e) {
/*  999 */     this.mouseX = e.getX();
/* 1000 */     this.mouseY = e.getY();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseEntered(MouseEvent arg0) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseExited(MouseEvent arg0) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseReleased(MouseEvent arg0) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mousePressed(MouseEvent e) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void mouseDragged(MouseEvent e) {
/* 1029 */     this.mouseX = e.getX();
/* 1030 */     this.mouseY = e.getY();
/*      */   }
/*      */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\World.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */