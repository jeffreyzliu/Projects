/*    */ package com.assets;
/*    */ 
/*    */ import java.awt.event.KeyEvent;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ public class Manual
/*    */   extends Popup
/*    */ {
/*    */   public void loadPages() {
/*    */     try {
/* 13 */       for (int i = 1; i <= 5; i++) {
/* 14 */         this.pages.put(
/* 15 */             Integer.valueOf(i), 
/* 16 */             ImageIO.read(getClass().getResource(
/* 17 */                 "/com/assets/manual/" + i + ".png")));
/*    */       }
/* 19 */     } catch (IOException iOException) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void keyPressed(KeyEvent e) {
/* 27 */     if (e.getKeyCode() == 49) {
/* 28 */       this.pageNumber = 1;
/* 29 */       this.rerender = true;
/* 30 */     } else if (e.getKeyCode() == 50) {
/* 31 */       this.pageNumber = 2;
/* 32 */       this.rerender = true;
/* 33 */     } else if (e.getKeyCode() == 51) {
/* 34 */       this.pageNumber = 3;
/* 35 */       this.rerender = true;
/* 36 */     } else if (e.getKeyCode() == 52) {
/* 37 */       this.pageNumber = 4;
/* 38 */       this.rerender = true;
/* 39 */     } else if (e.getKeyCode() == 53) {
/* 40 */       this.pageNumber = 5;
/* 41 */       this.rerender = true;
/*    */     } 
/* 43 */     if (e.getKeyCode() == 37 && this.pageNumber > 1) {
/* 44 */       this.pageNumber--;
/* 45 */       this.rerender = true;
/*    */     } 
/* 47 */     if (e.getKeyCode() == 39 && this.pageNumber < 5) {
/* 48 */       this.pageNumber++;
/* 49 */       this.rerender = true;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\Manual.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */