/*     */ package com.assets;
/*     */ 
/*     */ import com.resource.Resource;
/*     */ import java.awt.Canvas;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Polygon;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.image.BufferStrategy;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.JFrame;
/*     */ 
/*     */ 
/*     */ public class Trader
/*     */   extends Canvas
/*     */   implements MouseListener
/*     */ {
/*     */   private JFrame tradePanel;
/*     */   private Player p;
/*     */   private HashMap<Resource, Integer> bank;
/*     */   private HashMap<String, BufferedImage> sprites;
/*     */   private Polygon[] leftArrows;
/*     */   private Polygon[] rightArrows;
/*     */   private String message;
/*     */   
/*     */   public Trader(Player p) {
/*  35 */     this.p = p;
/*  36 */     this.bank = new HashMap(); byte b; int j; Resource[] arrayOfResource;
/*  37 */     for (j = arrayOfResource = Resource.values().length, b = 0; b < j; ) { Resource r = arrayOfResource[b];
/*  38 */       this.bank.put(r, Integer.valueOf(0)); b++; }
/*     */     
/*  40 */     this.sprites = new HashMap();
/*     */     try {
/*  42 */       this.sprites.put("EndTrade", ImageIO.read(new File(
/*  43 */               "src/com/assets/button/EndTrade.png")));
/*  44 */       this.sprites.put("Background", ImageIO.read(new File(
/*  45 */               "src/com/assets/background/TradeBackground.png")));
/*  46 */     } catch (IOException e) {
/*  47 */       e.printStackTrace();
/*     */     } 
/*  49 */     this.leftArrows = new Polygon[5];
/*  50 */     this.rightArrows = new Polygon[5];
/*  51 */     for (int i = 20; i < 170; i += 30) {
/*  52 */       int[] leftX = { 295, 275, 295 };
/*  53 */       int[] leftY = { 14 + i, 25 + i, 36 + i };
/*  54 */       int[] rightX = { 360, 380, 360 };
/*  55 */       int[] rightY = { 14 + i, 25 + i, 36 + i };
/*  56 */       this.leftArrows[(i - 20) / 30] = new Polygon(leftX, leftY, 3);
/*  57 */       this.rightArrows[(i - 20) / 30] = new Polygon(rightX, rightY, 3);
/*     */     } 
/*  59 */     this.message = "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void openTradeWindow() {
/*  67 */     this.tradePanel = new JFrame();
/*  68 */     this.tradePanel.setSize(new Dimension('Ɛ', 'Ĭ'));
/*  69 */     this.tradePanel.setDefaultCloseOperation(2);
/*  70 */     this.tradePanel.setResizable(false);
/*  71 */     this.tradePanel.setLocationRelativeTo(null);
/*  72 */     this.tradePanel.add(this);
/*  73 */     this.tradePanel.setVisible(true);
/*  74 */     this.tradePanel.createBufferStrategy(2);
/*  75 */     this.tradePanel.setTitle("Trade");
/*  76 */     addMouseListener(this);
/*     */   }
/*     */   public void finishTrade() {
/*     */     byte b;
/*     */     int i;
/*     */     Resource[] arrayOfResource;
/*  82 */     for (i = arrayOfResource = Resource.values().length, b = 0; b < i; ) { Resource r = arrayOfResource[b];
/*  83 */       this.p.addR(r, ((Integer)this.bank.get(r)).intValue());
/*  84 */       this.bank.put(r, Integer.valueOf(0)); b++; }
/*     */     
/*  86 */     this.message = "";
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     removeMouseListener(this);
/*  92 */     if (this.tradePanel.isVisible()) this.tradePanel.dispose();
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void add(Resource r, int amt) {
/*  98 */     if (this.p.getR(r) >= amt) {
/*  99 */       this.bank.put(r, Integer.valueOf(((Integer)this.bank.get(r)).intValue() + amt));
/* 100 */       this.p.addR(r, -amt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void remove(Resource r, int amt) {
/* 107 */     if (((Integer)this.bank.get(r)).intValue() >= amt) {
/* 108 */       this.bank.put(r, Integer.valueOf(((Integer)this.bank.get(r)).intValue() - amt));
/* 109 */       this.p.addR(r, amt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void buy(Resource r, int amt) {
/* 116 */     int total = 4 * amt;
/* 117 */     int pos = 0;
/* 118 */     Resource[] res = Resource.values();
/* 119 */     while (total > 0) {
/* 120 */       if (((Integer)this.bank.get(res[pos])).intValue() == 0) {
/* 121 */         pos++; continue;
/*     */       } 
/* 123 */       this.bank.put(res[pos], Integer.valueOf(((Integer)this.bank.get(res[pos])).intValue() - 1));
/* 124 */       total--;
/*     */     } 
/*     */     
/* 127 */     this.p.addR(r, amt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTotal() {
/* 133 */     int total = 0;
/* 134 */     for (Resource r : this.bank.keySet()) {
/* 135 */       total += ((Integer)this.bank.get(r)).intValue();
/*     */     }
/* 137 */     return total;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 143 */   public boolean checkTrade(int amt) { return (getTotal() >= 4 * amt); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render() {
/* 151 */     BufferStrategy bs = getBufferStrategy();
/* 152 */     if (bs == null) {
/* 153 */       createBufferStrategy(2);
/*     */       return;
/*     */     } 
/* 156 */     Graphics g = bs.getDrawGraphics();
/*     */     
/* 158 */     g.setFont(new Font("Garamond", true, 12));
/* 159 */     g.drawImage((Image)this.sprites.get("Background"), 0, 0, 400, 300, null);
/*     */     
/* 161 */     g.setColor(Color.BLACK);
/* 162 */     renderResources(g);
/* 163 */     renderArrows(g);
/* 164 */     renderFunctions(g);
/* 165 */     renderBorders(g);
/*     */     
/* 167 */     g.dispose();
/* 168 */     bs.show();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderResources(Graphics g) {
/* 174 */     int yVal = 30; byte b; int i; Resource[] arrayOfResource;
/* 175 */     for (i = arrayOfResource = Resource.values().length, b = 0; b < i; ) { Resource r = arrayOfResource[b];
/* 176 */       g.drawImage(r.getIcon(), 10, yVal, 30, 30, null);
/* 177 */       g.drawImage(r.getIcon(), 300, yVal, 30, 30, null);
/* 178 */       g.drawString(this.p.getR(r), 40, yVal + 20);
/* 179 */       g.drawString(this.bank.get(r), 340, yVal + 20);
/* 180 */       yVal += 30;
/*     */       b++; }
/*     */   
/*     */   } public void renderArrows(Graphics g) {
/*     */     byte b;
/*     */     int i;
/*     */     Polygon[] arrayOfPolygon;
/* 187 */     for (i = arrayOfPolygon = this.leftArrows.length, b = 0; b < i; ) { Polygon p = arrayOfPolygon[b];
/* 188 */       g.fillPolygon(p); b++; }
/*     */     
/* 190 */     for (i = arrayOfPolygon = this.rightArrows.length, b = 0; b < i; ) { Polygon p = arrayOfPolygon[b];
/* 191 */       g.fillPolygon(p);
/*     */       b++; }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public void renderFunctions(Graphics g) {
/* 198 */     g.drawString("Resources", 5, 20);
/* 199 */     g.drawString("Resources for Purchase", 95, 20);
/* 200 */     g.drawString("Resources to Trade", 270, 20);
/* 201 */     int yVal = 34; byte b; int i; Resource[] arrayOfResource;
/* 202 */     for (i = arrayOfResource = Resource.values().length, b = 0; b < i; ) { Resource r = arrayOfResource[b];
/* 203 */       g.drawRect(80, yVal, 65, 22);
/* 204 */       g.drawString("+1 " + r.toString(), 85, yVal + 16);
/* 205 */       yVal += 30; b++; }
/*     */     
/* 207 */     g.drawString("for any 4 resources", 150, 110);
/* 208 */     g.drawString("Total:   " + getTotal(), 300, 200);
/* 209 */     g.drawString(this.message, 10, 245);
/* 210 */     g.drawImage((Image)this.sprites.get("EndTrade"), 265, 210, 130, 62, null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderBorders(Graphics g) {
/* 216 */     g.drawLine(70, 0, 70, 210);
/* 217 */     g.drawLine(265, 0, 265, 300);
/* 218 */     g.drawLine(0, 30, 400, 30);
/* 219 */     g.drawLine(0, 210, 400, 210);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 225 */     int i = 0;
/* 226 */     int mouseX = e.getX();
/* 227 */     int mouseY = e.getY(); byte b; int j; Resource[] arrayOfResource;
/* 228 */     for (j = arrayOfResource = Resource.values().length, b = 0; b < j; ) { Resource r = arrayOfResource[b];
/* 229 */       if (this.leftArrows[i].contains(mouseX, mouseY)) {
/* 230 */         remove(r, 1);
/*     */       }
/* 232 */       if (this.rightArrows[i].contains(mouseX, mouseY)) {
/* 233 */         add(r, 1);
/*     */       }
/* 235 */       if (mouseX > 80 && mouseX < 145 && mouseY > 34 + 30 * i && 
/* 236 */         mouseY < 56 + 30 * i) {
/* 237 */         if (checkTrade(1)) {
/* 238 */           buy(r, 1);
/* 239 */           this.message = "Trade successful.";
/*     */         } else {
/* 241 */           this.message = "Not enough resources to perform trade.";
/*     */         } 
/*     */       }
/* 244 */       i++; b++; }
/*     */     
/* 246 */     if (mouseX > 265 && mouseX < 400 && mouseY > 210 && mouseY < 300)
/* 247 */       finishTrade(); 
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent arg0) {}
/*     */   
/*     */   public void mouseExited(MouseEvent arg0) {}
/*     */   
/*     */   public void mousePressed(MouseEvent arg0) {}
/*     */   
/*     */   public void mouseReleased(MouseEvent arg0) {}
/*     */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\Trader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */