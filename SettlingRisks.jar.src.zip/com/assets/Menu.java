/*     */ package com.assets;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ public class Menu
/*     */   implements MouseListener, MouseMotionListener
/*     */ {
/*     */   private String[] playerNames;
/*     */   private HashMap<String, BufferedImage> buttonSprites;
/*     */   private BufferedImage background;
/*     */   private BufferedImage title;
/*     */   private Manual manual;
/*     */   private Credits credits;
/*     */   private int counter;
/*     */   private int mouseX;
/*     */   private int mouseY;
/*     */   private boolean stopRunning;
/*     */   
/*     */   public Menu() {
/*  30 */     this.buttonSprites = new HashMap();
/*  31 */     loadButton("Play");
/*  32 */     loadButton("PlayDark");
/*  33 */     loadButton("HowToPlay");
/*  34 */     loadButton("HowToPlayDark");
/*  35 */     loadButton("Quit");
/*  36 */     loadButton("QuitDark");
/*  37 */     loadButton("Credits");
/*  38 */     loadButton("CreditsDark");
/*     */     try {
/*  40 */       this.background = ImageIO.read(getClass().getResource(
/*  41 */             "/com/assets/background/MenuBackground.jpg"));
/*  42 */       this.title = ImageIO.read(getClass().getResource("/com/assets/Title.png"));
/*  43 */     } catch (IOException e) {
/*  44 */       e.printStackTrace();
/*     */     } 
/*     */     
/*  47 */     this.counter = 0;
/*  48 */     this.mouseX = 0;
/*  49 */     this.mouseY = 0;
/*  50 */     this.stopRunning = false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadButton(String name) {
/*     */     try {
/*  57 */       this.buttonSprites.put(
/*  58 */           name, 
/*  59 */           ImageIO.read(getClass().getResource(
/*  60 */               "/com/assets/button/" + name + ".png")));
/*  61 */     } catch (IOException e) {
/*  62 */       System.out.println("failed");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void inputPlayerNumb(String err) {
/*     */     try {
/*  70 */       int playerNumb = Integer.parseInt(JOptionPane.showInputDialog(null, 
/*  71 */             String.valueOf(err) + "\nNumber of Players (2-4): "));
/*  72 */       if (playerNumb == 2 || playerNumb == 3 || playerNumb == 4) {
/*  73 */         this.playerNames = new String[playerNumb];
/*     */       } else {
/*  75 */         inputPlayerNumb("Your input was invalid. Please retry. \n");
/*     */       } 
/*  77 */     } catch (NumberFormatException e) {
/*  78 */       inputPlayerNumb("Your input was invalid. Please retry. \n");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void inputPlayerName(String err) {
/*  85 */     String playerName = JOptionPane.showInputDialog(null, String.valueOf(err) + "\nPlayer " + (
/*  86 */         this.counter + 1) + ":");
/*  87 */     boolean valid = true;
/*  88 */     for (int i = 0; i < this.counter; i++) {
/*  89 */       if (this.playerNames[i].equals(playerName)) {
/*  90 */         valid = false;
/*     */         break;
/*     */       } 
/*     */     } 
/*  94 */     if (valid) {
/*  95 */       this.playerNames[this.counter] = playerName;
/*  96 */       this.counter++;
/*     */     } else {
/*  98 */       inputPlayerName("Player name is already in use. Please retry. \n");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkFinished() {
/*     */     try {
/* 106 */       return (this.counter == this.playerNames.length);
/* 107 */     } catch (NullPointerException e) {
/* 108 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   public boolean quitGame() { return this.stopRunning; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public String[] getPlayers() { return this.playerNames; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void render(Graphics g) {
/* 127 */     g.drawImage(this.background, 0, 0, 1200, 900, null);
/* 128 */     g.drawImage(this.title, 300, 0, 600, 200, null);
/* 129 */     renderButtons(g);
/*     */     
/*     */     try {
/* 132 */       this.manual.render();
/* 133 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 138 */       this.credits.render();
/* 139 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void renderButtons(Graphics g) {
/* 147 */     if (this.mouseX > 450 && this.mouseX < 750 && this.mouseY > 200 && this.mouseY < 300) {
/* 148 */       g.drawImage((Image)this.buttonSprites.get("PlayDark"), 450, 200, 300, 100, null);
/*     */     } else {
/* 150 */       g.drawImage((Image)this.buttonSprites.get("Play"), 450, 200, 300, 100, null);
/*     */     } 
/* 152 */     if (this.mouseX > 450 && this.mouseX < 750 && this.mouseY > 325 && this.mouseY < 425) {
/* 153 */       g.drawImage((Image)this.buttonSprites.get("HowToPlayDark"), 450, 325, 300, 100, 
/* 154 */           null);
/*     */     } else {
/* 156 */       g.drawImage((Image)this.buttonSprites.get("HowToPlay"), 450, 325, 300, 100, 
/* 157 */           null);
/*     */     } 
/* 159 */     if (this.mouseX > 450 && this.mouseX < 750 && this.mouseY > 450 && this.mouseY < 550) {
/* 160 */       g.drawImage((Image)this.buttonSprites.get("CreditsDark"), 450, 450, 300, 100, 
/* 161 */           null);
/*     */     } else {
/* 163 */       g.drawImage((Image)this.buttonSprites.get("Credits"), 450, 450, 300, 100, null);
/*     */     } 
/* 165 */     if (this.mouseX > 450 && this.mouseX < 750 && this.mouseY > 575 && this.mouseY < 675) {
/* 166 */       g.drawImage((Image)this.buttonSprites.get("QuitDark"), 450, 575, 300, 100, null);
/*     */     } else {
/* 168 */       g.drawImage((Image)this.buttonSprites.get("Quit"), 450, 575, 300, 100, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {
/* 175 */     int mouseX = e.getX();
/* 176 */     int mouseY = e.getY();
/* 177 */     if (mouseX > 450 && mouseX < 750 && mouseY > 200 && mouseY < 300) {
/* 178 */       inputPlayerNumb("");
/* 179 */       for (int i = 0; i < this.playerNames.length; i++) {
/* 180 */         inputPlayerName("");
/*     */       }
/*     */     } 
/* 183 */     if (mouseX > 450 && mouseX < 750 && mouseY > 325 && mouseY < 425) {
/*     */       try {
/* 185 */         if (!this.manual.isShowing()) {
/* 186 */           this.manual = new Manual();
/*     */         }
/* 188 */       } catch (NullPointerException ex) {
/* 189 */         this.manual = new Manual();
/*     */       } 
/*     */     }
/* 192 */     if (mouseX > 450 && mouseX < 750 && mouseY > 450 && mouseY < 550) {
/*     */       try {
/* 194 */         if (!this.credits.isShowing()) {
/* 195 */           this.credits = new Credits();
/*     */         }
/* 197 */       } catch (NullPointerException ex) {
/* 198 */         this.credits = new Credits();
/*     */       } 
/*     */     }
/* 201 */     if (mouseX > 450 && mouseX < 750 && mouseY > 575 && mouseY < 675) {
/* 202 */       this.stopRunning = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseDragged(MouseEvent e) {
/* 209 */     this.mouseX = e.getX();
/* 210 */     this.mouseY = e.getY();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {
/* 216 */     this.mouseX = e.getX();
/* 217 */     this.mouseY = e.getY();
/*     */   }
/*     */   
/*     */   public void mouseEntered(MouseEvent arg0) {}
/*     */   
/*     */   public void mouseExited(MouseEvent arg0) {}
/*     */   
/*     */   public void mousePressed(MouseEvent arg0) {}
/*     */   
/*     */   public void mouseReleased(MouseEvent arg0) {}
/*     */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\Menu.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */