/*    */ package com.assets;
/*    */ 
/*    */ import java.awt.event.KeyEvent;
/*    */ import java.io.IOException;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Credits
/*    */   extends Popup
/*    */ {
/*    */   public void loadPages() {
/*    */     try {
/* 14 */       this.pages.put(
/* 15 */           Integer.valueOf(1), 
/* 16 */           ImageIO.read(getClass().getResource(
/* 17 */               "/com/assets/credits/1.png")));
/* 18 */     } catch (IOException iOException) {}
/*    */   }
/*    */   
/*    */   public void keyPressed(KeyEvent e) {}
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\Credits.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */