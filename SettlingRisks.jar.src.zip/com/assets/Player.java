/*     */ package com.assets;
/*     */ 
/*     */ import com.resource.Resource;
/*     */ import com.structure.Structure;
/*     */ import com.terrain.Location;
/*     */ import com.terrain.Tile;
/*     */ import com.units.Unit;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Player
/*     */ {
/*     */   private String name;
/*     */   private HashMap<Location, Structure> buildings;
/*     */   private HashMap<Location, Unit> units;
/*     */   private HashMap<Resource, Integer> resources;
/*     */   private ArrayList<Location[]> roads;
/*     */   private ArrayList<Tile> ownedTiles;
/*     */   private Set<Location> ownedLocations;
/*     */   private Trader trader;
/*     */   
/*     */   public Player(String name) {
/*  28 */     this.resources = new HashMap();
/*  29 */     this.name = name;
/*  30 */     this.buildings = new HashMap();
/*  31 */     this.units = new HashMap();
/*  32 */     this.roads = new ArrayList();
/*  33 */     this.ownedTiles = new ArrayList();
/*  34 */     this.ownedLocations = new HashSet();
/*  35 */     this.resources.put(Resource.ORE, Integer.valueOf(0));
/*  36 */     this.resources.put(Resource.STONE, Integer.valueOf(4));
/*  37 */     this.resources.put(Resource.LUMBER, Integer.valueOf(4));
/*  38 */     this.resources.put(Resource.WOOL, Integer.valueOf(2));
/*  39 */     this.resources.put(Resource.GRAIN, Integer.valueOf(4));
/*  40 */     this.trader = new Trader(this);
/*     */   }
/*     */ 
/*     */   
/*     */   public int countVP() {
/*  45 */     int VP = 0;
/*  46 */     for (Location loc : this.buildings.keySet()) {
/*  47 */       if (((Structure)this.buildings.get(loc)).getName().equals("settlement")) {
/*  48 */         VP++; continue;
/*     */       } 
/*  50 */       VP += 2;
/*     */     } 
/*     */     
/*  53 */     return VP;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  58 */   public String getName() { return this.name; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  64 */   public void trade() { this.trader.openTradeWindow(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public Trader getTrader() { return this.trader; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public HashMap<Location, Unit> getUnits() { return this.units; }
/*     */ 
/*     */ 
/*     */   
/*  79 */   public void addR(Resource r, int amt) { this.resources.put(r, Integer.valueOf(((Integer)this.resources.remove(r)).intValue() + amt)); }
/*     */ 
/*     */ 
/*     */   
/*  83 */   public int getR(Resource r) { return ((Integer)this.resources.get(r)).intValue(); }
/*     */ 
/*     */   
/*     */   public boolean checkStruct(Structure s) {
/*  87 */     for (Resource r : s.req().keySet()) {
/*  88 */       if (((Integer)s.req().get(r)).intValue() > getR(r)) {
/*  89 */         return false;
/*     */       }
/*     */     } 
/*  92 */     return true;
/*     */   }
/*     */   
/*     */   public boolean checkRoad() {
/*  96 */     if (((Integer)this.resources.get(Resource.LUMBER)).intValue() >= 1 && (
/*  97 */       (Integer)this.resources.get(Resource.STONE)).intValue() >= 1) {
/*  98 */       return true;
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean checkUnit() {
/* 105 */     if (((Integer)this.resources.get(Resource.GRAIN)).intValue() >= 1) {
/* 106 */       return true;
/*     */     }
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean checkRoadLoc(Location loc1, Location loc2) {
/* 114 */     if (loc1.getX() == loc2.getX() && 
/* 115 */       Math.abs(loc1.getY() - loc2.getY()) == 1) {
/* 116 */       return true;
/*     */     }
/* 118 */     if (loc1.getY() == loc2.getY() && 
/* 119 */       Math.abs(loc1.getX() - loc2.getX()) == 1) {
/* 120 */       return true;
/*     */     }
/* 122 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void reset() {
/* 127 */     for (Location loc : this.units.keySet()) {
/* 128 */       ((Unit)this.units.get(loc)).reset();
/*     */     }
/*     */   }
/*     */   
/*     */   public void moveUnit(Location loc1, Location loc2) {
/* 133 */     if (this.units.containsKey(loc1)) {
/* 134 */       if (this.units.containsKey(loc2)) {
/* 135 */         System.out.println("contains");
/*     */         try {
/* 137 */           ((Unit)this.units.get(loc1)).add(-1);
/* 138 */           ((Unit)this.units.get(loc2)).add(1);
/* 139 */         } catch (Exception exception) {}
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/* 144 */           ((Unit)this.units.get(loc1)).add(-1);
/* 145 */           this.units.put(loc2, new Unit(true, this));
/* 146 */           System.out.println("success");
/* 147 */         } catch (Exception e) {
/* 148 */           System.out.println("moveUnit Exception");
/*     */         } 
/*     */       } 
/*     */       
/* 152 */       if (((Unit)this.units.get(loc1)).getAmount() < 1) {
/* 153 */         this.units.remove(loc1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void printSurrounding() {
/* 159 */     for (Tile t : this.ownedTiles) {
/* 160 */       System.out.println(t);
/*     */     }
/*     */   }
/*     */   
/*     */   public void addUnit(Location loc) {
/* 165 */     addR(Resource.GRAIN, -1);
/* 166 */     if (this.units.keySet().contains(loc)) {
/* 167 */       ((Unit)this.units.get(loc)).add();
/*     */     } else {
/* 169 */       this.units.put(loc, new Unit(true, this));
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addU(Location loc, int i) {
/*     */     try {
/* 175 */       ((Unit)this.units.get(loc)).add(i);
/* 176 */     } catch (Exception e) {
/*     */       
/* 178 */       e.printStackTrace();
/*     */     } 
/* 180 */     if (((Unit)this.units.get(loc)).getAmount() == 0) {
/* 181 */       this.units.remove(loc);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void addRoad(Location loc1, Location loc2) {
/* 187 */     if (loc1.getY() > loc2.getY() || loc1.getX() < loc2.getX()) {
/* 188 */       if (!this.roads.contains(new Location[] { loc1, loc2 })) {
/* 189 */         addR(Resource.LUMBER, -1);
/* 190 */         addR(Resource.STONE, -1);
/* 191 */         this.roads.add(new Location[] { loc1, loc2 });
/*     */       }
/*     */     
/* 194 */     } else if (!this.roads.contains(new Location[] { loc2, loc1 })) {
/* 195 */       addR(Resource.LUMBER, -1);
/* 196 */       addR(Resource.STONE, -1);
/* 197 */       this.roads.add(new Location[] { loc2, loc1 });
/*     */     } 
/*     */     
/* 200 */     this.ownedLocations.add(loc1);
/* 201 */     this.ownedLocations.add(loc2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void addBuilding(Location loc, Structure s) {
/* 206 */     if (!s.equals(this.buildings.get(loc))) {
/* 207 */       for (Resource r : s.req().keySet())
/* 208 */         addR(r, -1 * ((Integer)s.req().get(r)).intValue()); 
/* 209 */       this.buildings.remove(loc);
/* 210 */       this.buildings.put(loc, s);
/*     */     } 
/* 212 */     System.out.println(loc);
/* 213 */     this.ownedLocations.add(loc);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void addOwnedTiles(ArrayList<Tile> tiles) {
/* 219 */     for (Tile t : tiles) {
/* 220 */       this.ownedTiles.add(t);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 227 */   public ArrayList<Tile> getOwnedTiles() { return this.ownedTiles; }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean inOwnedTile(Location loc) {
/* 232 */     for (Tile t : this.ownedTiles) {
/* 233 */       if (t.getLoc().equals(loc)) {
/* 234 */         return true;
/*     */       }
/*     */     } 
/* 237 */     return false;
/*     */   }
/*     */   
/*     */   public boolean settlementAtLoc(Location loc) {
/* 241 */     System.out.println("called");
/* 242 */     if (this.buildings.containsKey(loc)) {
/* 243 */       return true;
/*     */     }
/* 245 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean buildingAtLoc(Location loc) {
/* 250 */     if (this.buildings.keySet().contains(loc)) {
/* 251 */       return true;
/*     */     }
/* 253 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 259 */   public HashMap<Location, Structure> getStruct() { return this.buildings; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 265 */   public ArrayList<Location[]> getRoads() { return this.roads; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void harvest(int prob) {
/* 271 */     Map<Resource, Integer> harvestValues = new HashMap<Resource, Integer>(); int i; Resource[] arrayOfResource;
/* 272 */     for (i = arrayOfResource = Resource.values().length, null = 0; null < i; ) { Resource r = arrayOfResource[null];
/* 273 */       harvestValues.put(r, Integer.valueOf(0)); null++; }
/*     */     
/* 275 */     for (Tile t : this.ownedTiles) {
/* 276 */       if (t.getResourceType() != null)
/* 277 */         harvestValues.put(
/* 278 */             t.getResourceType(), 
/* 279 */             Integer.valueOf(((Integer)harvestValues.get(t.getResourceType())).intValue() + 
/* 280 */               t.harvest(prob, this))); 
/*     */     } 
/* 282 */     for (Resource r : harvestValues.keySet()) {
/* 283 */       this.resources.put(r, Integer.valueOf(((Integer)this.resources.remove(r)).intValue() + ((Integer)harvestValues.get(r)).intValue()));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 290 */   public boolean validLoc(Location loc) { return this.ownedLocations.contains(loc); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 295 */   public boolean equals(Object o) { return ((Player)o).getName().equals(getName()); }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 300 */   public String toString() { return this.name; }
/*     */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\Player.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */