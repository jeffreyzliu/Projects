/*    */ package com.assets;
/*    */ 
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Dice
/*    */ {
/*    */   public int resourceRoll() {
/* 14 */     return (int)(Math.random() * 6.0D) + 1 + 
/* 15 */       (int)(Math.random() * 6.0D) + 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] battle(int attacker, int defender) {
/* 20 */     LinkedList<Integer> attackingRolls = new LinkedList<Integer>();
/* 21 */     LinkedList<Integer> defendingRolls = new LinkedList<Integer>();
/* 22 */     int[] result = new int[2];
/*    */     
/* 24 */     int numATK = Math.min(attacker, 3);
/* 25 */     int numDEF = Math.min(defender, 2);
/* 26 */     for (i = 0; i < numATK; i++) {
/* 27 */       attackingRolls.add(Integer.valueOf((int)(Math.random() * 6.0D + 1.0D)));
/*    */     }
/*    */     
/* 30 */     for (int i = 0; i < numDEF; i++) {
/* 31 */       defendingRolls.add(Integer.valueOf((int)(Math.random() * 6.0D + 1.0D)));
/*    */     }
/*    */     
/* 34 */     int numCompare = Math.min(attackingRolls.size(), defendingRolls.size());
/* 35 */     Collections.sort(attackingRolls);
/* 36 */     Collections.sort(defendingRolls);
/* 37 */     for (int i = 0; i < numCompare; i++) {
/* 38 */       if (((Integer)attackingRolls.get(i)).intValue() > ((Integer)defendingRolls.get(i)).intValue()) {
/* 39 */         result[1] = result[1] - 1;
/*    */       } else {
/* 41 */         result[0] = result[0] - 1;
/*    */       } 
/*    */     } 
/*    */     
/* 45 */     return result;
/*    */   }
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\Dice.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */