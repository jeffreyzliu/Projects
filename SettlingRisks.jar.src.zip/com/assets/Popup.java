/*    */ package com.assets;
/*    */ 
/*    */ import java.awt.Canvas;
/*    */ import java.awt.Color;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.event.KeyEvent;
/*    */ import java.awt.event.KeyListener;
/*    */ import java.awt.image.BufferStrategy;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.HashMap;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ public abstract class Popup
/*    */   extends Canvas
/*    */   implements KeyListener
/*    */ {
/*    */   protected JFrame frame;
/*    */   protected int pageNumber;
/*    */   protected boolean rerender;
/*    */   protected HashMap<Integer, BufferedImage> pages;
/*    */   
/*    */   public Popup() {
/* 25 */     this.pageNumber = 1;
/* 26 */     this.rerender = true;
/*    */     
/* 28 */     this.frame = new JFrame();
/* 29 */     this.frame.setSize(new Dimension('π', 'Ȝ'));
/* 30 */     this.frame.setDefaultCloseOperation(2);
/* 31 */     this.frame.setResizable(false);
/* 32 */     this.frame.setLocationRelativeTo(null);
/* 33 */     this.frame.add(this);
/* 34 */     this.frame.setVisible(true);
/* 35 */     this.frame.createBufferStrategy(2);
/* 36 */     this.frame.setTitle("How to Play");
/* 37 */     addKeyListener(this);
/*    */     
/* 39 */     this.pages = new HashMap();
/* 40 */     loadPages();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void closeManual() {
/* 46 */     removeKeyListener(this);
/* 47 */     this.frame.dispose();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void render() {
/* 53 */     BufferStrategy bs = getBufferStrategy();
/* 54 */     if (bs == null) {
/* 55 */       createBufferStrategy(2);
/*    */       return;
/*    */     } 
/* 58 */     Graphics g = bs.getDrawGraphics();
/*    */     
/* 60 */     if (this.rerender) {
/* 61 */       g.setColor(Color.WHITE);
/* 62 */       g.fillRect(0, 0, 960, 540);
/* 63 */       g.drawImage((Image)this.pages.get(Integer.valueOf(this.pageNumber)), 0, 0, 960, 540, null);
/* 64 */       this.rerender = false;
/*    */     } 
/*    */     
/* 67 */     g.dispose();
/* 68 */     bs.show();
/*    */   }
/*    */   
/*    */   public abstract void loadPages();
/*    */   
/*    */   public abstract void keyPressed(KeyEvent paramKeyEvent);
/*    */   
/*    */   public void keyReleased(KeyEvent arg0) {}
/*    */   
/*    */   public void keyTyped(KeyEvent arg0) {}
/*    */ }


/* Location:              C:\Users\Jeffrey Liu\Desktop\APCS\SettlingRisks.jar!\com\assets\Popup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.0.4
 */